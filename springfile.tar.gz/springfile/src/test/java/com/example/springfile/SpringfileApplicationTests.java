package com.example.springfile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringfileApplicationTests {

	@Test
	void contextLoads() {
	}

}
